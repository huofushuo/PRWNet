import os
from config import Config

opt = Config('training.yml')
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
gpus = ','.join([str(i) for i in opt.GPU])
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = gpus

import torch

torch.backends.cudnn.benchmark = True

import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader

import random
import time
import numpy as np
import datetime
from torchvision.utils import save_image

import utils
from data_RGB import get_training_data, get_validation_data
from MSRNet import MSRNet
import losses
from scheduler import GradualWarmupScheduler
from tqdm import tqdm
from pdb import set_trace as stx
from torchvision.models import vgg16
from PerceptualLoss import LossNetwork
import torch.optim.lr_scheduler
import ciplab_NTIRE_2020_master.LPIPS.models.dist_model as dm
from colorLoss import deltaEColorLoss



######### Set Seeds ###########
random.seed(1234)
np.random.seed(1234)
torch.manual_seed(1234)
torch.cuda.manual_seed_all(1234)

start_epoch = 1
mode = opt.MODEL.MODE
session = opt.MODEL.SESSION

result_dir = os.path.join(opt.TRAINING.SAVE_DIR, mode, 'results', session)
model_dir = os.path.join(opt.TRAINING.SAVE_DIR, mode, 'models', session)

utils.mkdir(result_dir)
utils.mkdir(model_dir)

train_dir = opt.TRAINING.TRAIN_DIR
val_dir = opt.TRAINING.VAL_DIR


def main():
    ######### Model ###########
    model_restoration = MSRNet()
    model_restoration.cuda()

    device_ids = [i for i in range(torch.cuda.device_count())]
    if torch.cuda.device_count() > 1:
        print("\n\nLet's use", torch.cuda.device_count(), "GPUs!\n\n")

    new_lr = 0.00002

    optimizer = optim.Adam(model_restoration.parameters(), lr=new_lr, betas=(0.9, 0.999), eps=1e-8)

    ######### Scheduler ###########
    # scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=1000, eta_min=4e-06)
    warmup_epochs = 3
    scheduler_cosine = optim.lr_scheduler.CosineAnnealingLR(optimizer, opt.OPTIM.NUM_EPOCHS-warmup_epochs, eta_min=opt.OPTIM.LR_MIN)
    scheduler = GradualWarmupScheduler(optimizer, multiplier=1, total_epoch=warmup_epochs, after_scheduler=scheduler_cosine)
    # scheduler.step()
    ######### Resume #######

    if opt.TRAINING.RESUME:

        path_chk_rest = utils.get_last_path(model_dir, '_108.pth')
        utils.load_checkpoint(model_restoration, path_chk_rest)
        # start_epoch = utils.load_start_epoch(path_chk_rest) + 1
        # utils.load_optim(optimizer, path_chk_rest)

        for i in range(1, start_epoch):
            scheduler.step()
        new_lr = scheduler.get_lr()[0]
        print('------------------------------------------------------------------------------')
        print("==> Resuming Training with learning rate:", new_lr)
        print('------------------------------------------------------------------------------')

    if len(device_ids) > 1:
        model_restoration = nn.DataParallel(model_restoration, device_ids=device_ids)

    ######### Loss ###########
    criterion_char = losses.CharbonnierLoss()
    criterion_edge = losses.EdgeLoss()
    criterion_color = deltaEColorLoss()

    vgg_model = vgg16(pretrained=True).features[:16]
    vgg_model = vgg_model.cuda()
    for param in vgg_model.parameters():
        param.requires_grad = False
    criterion_pl = LossNetwork(vgg_model).cuda()

    def clip_gradient(optimizer, grad_clip):
        for group in optimizer.param_groups:
            for param in group['params']:
                if param.grad is not None:
                    param.grad.data.clamp_(-grad_clip, grad_clip)

    ######### DataLoaders ###########
    train_dataset = get_training_data(train_dir, {'patch_size': opt.TRAINING.TRAIN_PS})
    train_loader = DataLoader(dataset=train_dataset, batch_size=opt.OPTIM.BATCH_SIZE, shuffle=True, num_workers=4,
                              drop_lat=False, pin_memory=True)

    val_dataset = get_validation_data(val_dir, {'patch_size': opt.TRAINING.VAL_PS})
    val_loader = DataLoader(dataset=val_dataset, batch_size=1, shuffle=False, num_workers=4, drop_last=False,
                            pin_memory=True)

    print('===> Start Epoch {} End Epoch {}'.format(start_epoch, opt.OPTIM.NUM_EPOCHS + 1))
    print('===> Loading datasets')

    best_psnr = 0
    best_epoch = 0

    for epoch in range(start_epoch, opt.OPTIM.NUM_EPOCHS + 1):
        epoch_start_time = time.time()
        epoch_loss = 0
        train_id = 1
    #####################################################################################
        # model_restoration.eval()
        # psnr_val_rgb = []
        # mse_val_rgb = []
        # times = []
        # for ii, data_val in enumerate((val_loader), 0):
        #     target = data_val[0].cuda()
        #     input_ = data_val[1].cuda()
        #     with torch.no_grad():
        #         start = time.time()
        #         s = time.time()
        #         restored = model_restoration(input_)
        #         times.append(time.time() - s)
        #         end = time.time()
        #         print(end - start)
        #     restored = restored[0]
        #     name2 = name1 = data_val[2][0]
        #     restored = (restored - torch.min(restored)) / (torch.max(restored) - torch.min(restored) + 1e-8)
        #     save_image((restored.squeeze().cpu().data), './results/{}/{}.png'.format('our', name1 ))
        #     save_image((target.squeeze().cpu().data), './results/{}/{}.png'.format('gt', name2))
        #     for res, tar in zip(restored, target):
        #         psnr_val_rgb.append(utils.torchPSNR(res, tar))
        #         mse_val_rgb.append(utils.torchMSE(res, tar))
        # psnr_val_rgb = torch.stack(psnr_val_rgb).mean().item()
        # mse_val_rgb = torch.stack(mse_val_rgb).mean().item()
        # Ttime, Mtime = np.sum(times[1:]), np.mean(times[1:])
        # print(psnr_val_rgb, mse_val_rgb, 1./Mtime)
    ###################################################################################################

        model_restoration.train()
        for i, data in enumerate(tqdm(train_loader), 0):

            # zero_grad
            for param in model_restoration.parameters():
                param.grad = None

            target = data[0].cuda()
            input_ = data[1].cuda()

            restored = model_restoration(input_)

            # Compute loss at each stage
            loss_char = np.sum([criterion_char(restored[j], target) for j in range(len(restored))])
            loss_edge = np.sum([criterion_edge(restored[j], target) for j in range(len(restored))])
            loss_pl = np.sum([criterion_pl(restored[j], target) for j in range(len(restored))])
            # loss_color = np.sum([criterion_color(restored[j], target) for j in range(len(restored))])
            # loss_LPIPS0, _ = model_LPIPS.forward_pair(restored[0], target)
            # loss_LPIPS0 = torch.mean(loss_LPIPS0)
            # loss_LPIPS1, _ = model_LPIPS.forward_pair(restored[1], target)
            # loss_LPIPS1 = torch.mean(loss_LPIPS1)
            # loss_LPIPS2, _ = model_LPIPS.forward_pair(restored[2], target)
            # loss_LPIPS2 = torch.mean(loss_LPIPS2)
            # loss_LPIPS = loss_LPIPS0+loss_LPIPS1+loss_LPIPS2

            loss = (loss_char) + (0.5 * loss_edge) + (0.2 * loss_pl)

            # clip_gradient(optimizer, 2)
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()
            scheduler.step()
            epoch_loss = epoch_loss + loss.item()

        #### Evaluation ####
        if epoch % opt.TRAINING.VAL_AFTER_EVERY == 0:
            model_restoration.eval()
            psnr_val_rgb = []
            for ii, data_val in enumerate((val_loader), 0):
                data_val[0] = (data_val[0]-torch.min(data_val[0]))/(torch.max(data_val[0]) - torch.min(data_val[0]) + 1e-8)
                target = data_val[0].cuda()
                input_ = data_val[1].cuda()

                with torch.no_grad():
                    restored = model_restoration(input_)
                restored = restored[0]

                for res, tar in zip(restored, target):
                    psnr_val_rgb.append(utils.torchPSNR(res, tar))

            psnr_val_rgb = torch.stack(psnr_val_rgb).mean().item()

            if psnr_val_rgb > best_psnr:
                best_psnr = psnr_val_rgb
                best_epoch = epoch
                torch.save({'epoch': epoch,
                            'state_dict': model_restoration.state_dict(),
                            'optimizer': optimizer.state_dict()
                            }, os.path.join(model_dir, "model_best.pth"))

            print("[epoch %d PSNR: %.4f --- best_epoch %d Best_PSNR %.4f]" % (epoch, psnr_val_rgb, best_epoch, best_psnr))

            torch.save({'epoch': epoch,
                        'state_dict': model_restoration.state_dict(),
                        'optimizer': optimizer.state_dict()
                        }, os.path.join(model_dir, f"model_epoch_{epoch}.pth"))

        print("------------------------------------------------------------------")
        print("Epoch: {}\tTime: {:.4f}\tLoss: {:.4f}\tLearningRate {:.6f}".format(epoch, time.time() - epoch_start_time,
                                                                                  epoch_loss, scheduler.get_lr()[0]))
        print("------------------------------------------------------------------")

        torch.save({'epoch': epoch,
                    'state_dict': model_restoration.state_dict(),
                    'optimizer': optimizer.state_dict()
                    }, os.path.join(model_dir, "model_latest.pth"))

if __name__ == '__main__':
    main()


